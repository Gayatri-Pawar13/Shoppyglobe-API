const express = require("express");
const dotenv = require("dotenv");
const connectDB = require("./db");
const productRoutes = require("./routes/productRoutes");
const cartRoutes = require("./routes/cartRoutes");
const authRoutes = require("./routes/authRoutes");
const { errorHandler } = require("./middleware/errorMiddleware");

dotenv.config();
const app = express();

// Middleware
app.use(express.json());

// DB Connect
connectDB();

// Routes
app.use("/products", productRoutes);
app.use("/cart", cartRoutes);
app.use("/", authRoutes); // handles /register and /login

// Error Handler
app.use(errorHandler);

// Port
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
