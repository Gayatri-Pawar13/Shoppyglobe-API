const errorHandler = (err, req, res, next) => {
  // Set default status code
  const statusCode = res.statusCode === 200 ? 500 : res.statusCode;

  res.status(statusCode).json({
    message: err.message || "Server Error",
    stack: process.env.NODE_ENV === "production" ? "🥞 hidden" : err.stack,
  });
};

module.exports = { errorHandler };
